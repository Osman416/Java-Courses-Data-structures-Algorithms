package StatusCodes.Redirections;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Lab3
 */
@WebServlet("/Lab3")
public class Lab3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Lab3() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		String name = request.getParameter("searchEngine");
		if (name.contains("google")) {
			response.sendRedirect("http://google.ca");
		} else if (name.contains("Yahoo")){
			response.sendRedirect("http://yahoo.ca");
		} else if (name.contains("Bing")){
			response.sendRedirect("http://bing.ca");
		} else {
			response.sendError(HttpServletResponse.SC_NOT_FOUND,
					"The search engine cannot be found");
		}
		
	}

}
