package ca.gbc.labtest2a.problem2.driver;

import java.util.ArrayList;
import java.util.List;

import ca.gbc.labtest2a.problem2.list.MyList;

public class TestProblem2 {

	public static void main(String[] args) {

		/* LAB TEST 2A - PROBLEM 2 */
		
		//Create and output original list
		List<Integer> list = new ArrayList<Integer>();
		list.add(3);
		list.add(7);
		list.add(9);
		list.add(2);
		list.add(5);
		list.add(5);
		list.add(8);
		list.add(5);
		list.add(6);
		list.add(3);
		list.add(4);
		list.add(7);
		list.add(3);
		list.add(1);
		
		//print out original list
		System.out.println(list);

		//Call removeInvalidPairs
		System.out.println(MyList.removeInvalidPairs(list));
	}
	
	

}
