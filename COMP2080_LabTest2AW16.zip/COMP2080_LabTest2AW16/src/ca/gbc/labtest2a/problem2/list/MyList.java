package ca.gbc.labtest2a.problem2.list;

import java.util.List;

public class MyList {

	public static List<Integer> removeInvalidPairs(List<Integer> list){
		
		//return empty list if null or empty
		if( list==null || list.size()==0 )
			return list;
		
		//remove last element if odd size list
		if( list.size()%2 != 0 )
			list.remove(list.size()-1);
		else{
			    //loop thru removing invalid pairs
			    int i = 0;
			    boolean again = true;
		    	while( again ){
		    		if(list.get(i)>list.get(i+1)){
		    			list.remove(i);
		    			list.remove(i);		    			
		    		}else{
		    			i = i + 2;
		    		}
		    		
		    		//test counter for validitiy before continuing
		    		if(!(i<list.size()))
		    			again = false;
		    	}
						
		}
		return list;
				
	}

	
	
}
