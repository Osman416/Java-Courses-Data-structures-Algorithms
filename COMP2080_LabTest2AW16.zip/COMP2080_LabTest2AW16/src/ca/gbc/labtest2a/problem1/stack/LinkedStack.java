package ca.gbc.labtest2a.problem1.stack;

/* PLEASE NOTE THIS CLASS MODIFIED OBNTAINED FROM WEEK3 */
public class LinkedStack<T> implements StackInterface<T> {
	
	protected LLNode<T> stack;

	@Override
	public synchronized T pop()  {
		LLNode<T> aNode = null;
		if(!isEmpty()) {
			aNode = stack;
			stack = stack.getLink();
		}		
		return (T) aNode;
	}

	@Override
	public synchronized boolean isEmpty() {
		if(stack==null) 
			return true;
		else return false;
	}

	@Override
	public synchronized void push(T element) {
		LLNode<T> topNode = new LLNode<T>(element);
		topNode.setLink(stack);
		stack = topNode;

	}

}
