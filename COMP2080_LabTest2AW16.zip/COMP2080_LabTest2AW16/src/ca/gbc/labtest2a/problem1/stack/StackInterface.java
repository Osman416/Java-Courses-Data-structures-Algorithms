package ca.gbc.labtest2a.problem1.stack;

/* PLEASE NOTE THIS CLASS WAS OBNTAINED FROM WEEK3 */
public interface StackInterface<T> {
	
	void push(T element);
	
	T pop();
	// Throws StackunderflowException if this stack is empty
	// otherwise removes the top element from the stack
	
	boolean isEmpty();
	// Returns true if this stack is empty, otherwise returns false

}
