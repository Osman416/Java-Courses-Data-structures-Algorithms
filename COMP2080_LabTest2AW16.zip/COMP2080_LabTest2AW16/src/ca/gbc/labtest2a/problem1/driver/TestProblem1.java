package ca.gbc.labtest2a.problem1.driver;

import ca.gbc.labtest2a.problem1.runnable.Consumer;
import ca.gbc.labtest2a.problem1.runnable.Producer;
import ca.gbc.labtest2a.problem1.stack.LinkedStack;

public class TestProblem1 {

	// TEST PROBLEM 1: MAIN DRIVER CLASS
	// PURPOSE IS TO VERFIY WE CAN SAFELY PUSH AND POP OUR STACK
	public static void main(String[] args) throws InterruptedException {
		LinkedStack<String> stack = new LinkedStack<String>();
		final int THREADS = 2;
		final int REPETITIONS = 10;

		for (int i = 1; i <= THREADS; ++i) {
			Producer pr = new Producer(stack, REPETITIONS);
			Consumer cr = new Consumer(stack, REPETITIONS);

			Thread dt = new Thread(pr);
			Thread wt = new Thread(cr);

			dt.start();
			wt.start();

		}
		
	}

}
