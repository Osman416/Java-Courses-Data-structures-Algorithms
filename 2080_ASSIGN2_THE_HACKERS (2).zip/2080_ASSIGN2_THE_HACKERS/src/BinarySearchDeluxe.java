
public class BinarySearchDeluxe {

	public static int firstIndexOf(Term[] a, Term key, Comparator<Term> comparator) {
		//TODO: Implement firstIndexOf
		return -1;
	}
	
	public static int lastIndexOf(Term[] a, Term key, Comparator<Term> comparator) {
		//TODO: Implement lastIndexOf	
		return -1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
	}

}
