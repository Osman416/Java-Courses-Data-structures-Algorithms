import java.lang.*;
import java.util.*;
import java.util.Comparator;

public class AutoComplete {

	    private final Term[] terms;

	    //Constructor
	    public AutoComplete(final Term[] terms) { 
	        this.terms = terms;
	    }

	    //Return all terms that start with the prefix in descending order of weights
	    public Term[] allMatches(final String prefix) { 
	        int start = BinarySearchDeluxe.firstIndexOf(terms, prefix, Term.byPrefixOrder);
	        final int end = BinarySearchDeluxe.firstIndexOf(terms, prefix, Term.byPrefixOrder);

	        final Term[] matches = new Term[end - start];

	        for(int i = 0; start <= end; i++, start++) { 
	            matches[i] = this.terms[start];
	        }

	        return matches;
	    }
	    /*
	     public int numberOfMatches(String prefix) {
	         TrieNode lastNode = root;
	         boolean flag = false;
	         //System.out.println(root.getChar() + " -->" + root.getNumOfChildren());
	         for (int i = 0; i < prefix.length(); i++) {
	             if (lastNode.getChild(prefix.charAt(i)) != null) {
	                 lastNode = lastNode.getChild(prefix.charAt(i));
	                 //System.out.println(prefix.charAt(i) + " -> " + lastNode.getNumOfChildren());
	             }
	             else flag = true;
	         }
	         if(flag != true)
	            return lastNode.getNumOfChildren();
	        return 0;
	     }
	     */

	    	
	    	}
}
