/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pendulum;

import java.util.logging.Level;
import java.util.logging.Logger;
import java.awt.*;
import java.awt.event.*;
import javax.swing;
public class Pendulum extends JFrame
{
private KeyboardPanel keyboardPanel = new KeyboardPanel();
private javax.swing.Timer timer;
private int x1, x2, y1, y2, ms;
public Pendulum ( )
{
add(keyboardPanel);
keyboardPanel.setFocusable(true);
timer = new Timer (1000, new TimerListener());
timer.start();
}
@Override public void paint(Graphics g)
{
super.paint(g);
g.drawLine(x1, y1, x2, y2);
g.fillOval(x2, y2, 10, 10);
}
Public static void main(String [] args)
{
Pendulum frame= new Pendulum( );
frame.setTitle("Pendulum swing");
frame.setSize(500,500);
frame.setLocationRelativeTo(null);
frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
frame.setVisible(true);
}
}
class KeyboardPanel extends JPanel
{
public KeyboardPanel(){
            x1 = 200;
            y1 = 400;
            x2 = 200;
            y2 = 100;
            ms = 300;
            addKeyListener(new KeyAdapter(){
                @Override
public void keyPressed(KeyEvent e)
{
switch (e.getKeyCode()){
case KeyEvent.VK_Left:try
{
LeftKey();
} catch (InterruptedException ex) {
Logger.getLogger(Pendulum.class.getName()).
                        log(Level.SEVERE, null, ex);
break;
case KeyEvent.VK_DOWN: downKey(); break;
case KeyEvent.VK_Right: RightKey(); break;
case KeyEvent.VK_UP: upKey(); break;
}
repaint();
}
});
}
public void LeftKey() throws InterruptedException{
timer.wait();
}
public void RightKey(){
timer.notify();
}
        public void downKey(){
ms--;
}
public void upKey(){
            ms++;
}
}
class TimerListener implements ActionListener
{
public void actionPerformed(ActionEvent a){
if(x2<=200){
x2--;
y2--;
repaint();
}
else
{
x2++;
y2++;
}
}
}
}

