package Tests_pkg;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestTiming {

	@Test
	public void testFactInt() {
		fail("Not yet implemented");
	}

	@Test
	public void testFactLong() {
		fail("Not yet implemented");
	}

	@Test
	public void testFactInteger() {
		fail("Not yet implemented");
	}

	@Test
	public void testFactFloat() {
		fail("Not yet implemented");
	}

	@Test
	public void testFactDouble() {
		fail("Not yet implemented");
	}

	@Test
	public void testFactr() {
		fail("Not yet implemented");
	}

	@Test
	public void testFactBigInteger() {
		fail("Not yet implemented");
	}

	@Test
	public void testDaffy() {
		fail("Not yet implemented");
	}

	@Test
	public void testDonald() {
		fail("Not yet implemented");
	}

	@Test
	public void testDonaldb() {
		fail("Not yet implemented");
	}

	@Test
	public void testRandomarr() {
		fail("Not yet implemented");
	}

	@Test
	public void testPrintarr() {
		fail("Not yet implemented");
	}

	@Test
	public void testPrintIarr() {
		fail("Not yet implemented");
	}

	@Test
	public void testMickey() {
		fail("Not yet implemented");
	}

	@Test
	public void testMickeyi() {
		fail("Not yet implemented");
	}

	@Test
	public void testMinnie() {
		fail("Not yet implemented");
	}

	@Test
	public void testGoofy() {
		fail("Not yet implemented");
	}

	@Test
	public void testElmer() {
		fail("Not yet implemented");
	}

	@Test
	public void testPluto() {
		fail("Not yet implemented");
	}

	@Test
	public void testPlutob() {
		fail("Not yet implemented");
	}

	@Test
	public void testGyrob() {
		fail("Not yet implemented");
	}

	@Test
	public void testGyro() {
		fail("Not yet implemented");
	}

}
