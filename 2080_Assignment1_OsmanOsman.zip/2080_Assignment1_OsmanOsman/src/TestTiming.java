/*
	NAME: OSMAN OSMAN
	ID: 100962928
	CRN:46311
*/
import java.math.BigInteger;
import java.sql.Time;
import java.util.Arrays;

public class TestTiming {
	public static void main(String[] args) {
	
	
	Stopwatch time = new Stopwatch();
	
	/*A: For method daffy() develop a new method (called by your driver) to test and time this function
	testing for values of n from 30 through 44. Plot your results/analysis*/
	for(int i = 30; i <= 44; i++){
		
	    time.start();
	    Timing.daffy(i);
	    time.stop();
	    
	    System.out.println("Daffy value " + i + " : " + time);
	}
	//B: Repeat a) with method donald()
	for(int i = 30; i <= 44; i++){
		
	    time.start();
	    Timing.donald(i);
	    time.stop();
	    
	    System.out.println("Donald value " + i + " : " + time);
	}
	/*C: Develop a new method (called by your driver) to test mickey(). To initialize, make an array of
	size n with randomarr(n). The initialization of the array should not be inside the timing calls. Use
	values of n of 1000, 2000, 4000 ... through to 8192000*/
	for(int i = 1000; i <= 8192000; i *= 2){
	    int[] array = Timing.randomarr(i);
	    	System.out.println(Arrays.toString(array));
	    time.start();
	    Timing.mickey(array);
	    time.stop();
	    
	    System.out.println("Mickey time for value " + i + " : " + time);
	}
	//D: do same as "C:" for minnie() BUT ... through to 256000
	for(int i = 1000; i <= 256000; i *= 2){
	    int[] array = Timing.randomarr(i);
	    	System.out.println(Arrays.toString(array));
	    time.start();
	    Timing.minnie(array);
	    time.stop();
	    
	    System.out.println("Minnie time for value " + i + " : " + time);
    }
	//E: do same as "D:" for goofy() and pluto()
	for(int i = 1000; i <= 256000; i *= 2){
	    int[] array = Timing.randomarr(i);
	    	System.out.println(Arrays.toString(array));
	    time.start();
	    Timing.goofy(array);
	    time.stop();
	    
	    System.out.println("Goofy time for value " + i + " : " + time);
	}
	
	for(int i = 1000; i <= 256000; i *= 2){
	    int[] array = Timing.randomarr(i);
	    	System.out.println(Arrays.toString(array));
	    time.start();
	    Timing.pluto(array);
	    time.stop();
	    
	    System.out.println("Pluto time for value " + i + " : " + time);
	}
	/*F: Develop a new method (called by your driver) to test gyro(). For gyro(), make an array using
	randomarr(n) and call pluto on it first (pluto should not be included in the timing). Use values of
	n of 1000, 2000, 4000 � through 256000*/
	for(int i = 1000; i <= 256000; i *= 2){
		int[] array = Timing.randomarr(i);
		Timing.pluto(array);
		
		time.start();
		Timing.gyro(array);
		time.stop();
		
		System.out.println("Gyro time for value " + i + " : " + time);
	}
	/*G: Develop a new method (called by your driver) to test fact(BigInteger n). For fact(BigInterger n),
	test values n from 1000 through to 64000, doubling n each time*/
	int number = 6;
	int n = Timing.fact(number);
	System.out.println(n);
	
	//bigInteger test
	for(int i = 1000; i <= 64000; i *= 2){
		BigInteger bign = BigInteger.valueOf((long) i);
		
		time.start();
		Timing.fact(bign);
		time.stop();
		
		System.out.println("Big Integer with n as " + i + " " + time);
	}
	}

}
