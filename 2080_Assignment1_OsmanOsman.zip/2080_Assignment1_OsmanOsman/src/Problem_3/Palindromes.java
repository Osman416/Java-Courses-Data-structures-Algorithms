/*
	NAME: OSMAN OSMAN
	ID: 100962928
	CRN:46311
*/
package Problem_3;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;
import java.io.*;

public class Palindromes {
	public static void main(String[] args) throws IOException {
		BufferedReader buffRead = new BufferedReader(new FileReader("C:\\Users\\Osman\\Desktop\\palindrome.txt"));
		PrintStream printS = new PrintStream(new File("palindrome.txt"));
		//boolean palindrome;
		String input;
		input = buffRead.readLine();
		while (input != null) {
			if (isPalindrome(input))
				printS.println(input + " Is A Palindrome!");
			else
				printS.println(input + " Is NOT A Palindrome!");
			input = buffRead.readLine();
			
		}
	}

 	//Return value is true only if input string is a palindrome.
	//Character case and non-letters are ignored
	
	public static boolean isPalindrome(String input) {
		Queue<Character> que = new LinkedList<Character>();
		Stack<Character> stk = new Stack<Character>();
		Character letter; // 1 character from the input string
		int error = 0; // # of errors
		int i; // Index for input string
		for (i = 0; i < input.length(); i++) {
			letter = input.charAt(i);
			if (Character.isLetter(letter)) {
				que.add(letter);
				stk.push(letter);
			}
		}
		while (!que.isEmpty()) {
			if (que.remove() != stk.pop())
				error++;
		}
		// If no mismatches found , then the string is a palindrome.
		return (error == 0);
	}
}
