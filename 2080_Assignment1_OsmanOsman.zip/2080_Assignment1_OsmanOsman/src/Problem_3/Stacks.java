/*
	NAME: OSMAN OSMAN
	ID: 100962928
	CRN:46311
*/
package Problem_3;


import java.util.Stack;

public class Stacks<AnyType> {

	Stack<AnyType> charstack = new Stack<AnyType>();
	int topofstack;

	public void Stack() {
		topofstack = -1;
	}

	public void push(AnyType i) {
		charstack.add(i);
		topofstack++;
	}

	public AnyType pop() throws Exception {
		if (charstack.isEmpty() == true)
			throw new Exception("You are going to pop an empty stack");
		topofstack--;
		return charstack.remove(charstack.size() - 1);
	}

	public AnyType peek() throws Exception {
		if (charstack.isEmpty() == true)
			throw new Exception("You are going to peek an empty stack");
		return charstack.get(charstack.size() - 1);
	}

	public boolean isEmpty() {
		return (charstack.size() == 0);
	}
}
