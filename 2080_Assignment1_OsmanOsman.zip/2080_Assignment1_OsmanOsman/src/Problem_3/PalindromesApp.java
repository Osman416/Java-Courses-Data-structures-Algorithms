/*
	NAME: OSMAN OSMAN
	ID: 100962928
	CRN:46311
*/
package Problem_3;
import java.util.*;
import java.io.IOException;
import java.io.*;
import java.util.Stack;

public class PalindromesApp {
	
	public static void main(String[] args) throws IOException, FileNotFoundException {

		File inputFile = new File(args[0]);

		FileReader fileRead = new FileReader(inputFile);

		BufferedReader buffRead = new BufferedReader(fileRead);

		// displays lines in the text file
		int lines = 0;
		int count = 0;

		String setLine;

		while ((setLine = buffRead.readLine()) != null) {

			lines++;
			//public Object stack;
			Stack stack = new Stack();
			
			String inputString = setLine.replaceAll("[^a-zA-Z ]", "").toLowerCase();

			inputString = inputString.replaceAll(" ", "");

			for (int i = 0; i < inputString.length(); i++) {
				stack.pushStack(inputString.charAt(i));
			}

			String reverseString = "";
			
			while (!stack.isNull()) {
				reverseString = reverseString + Problem_3.Stacks.pop();
			}

			if (inputString.equals(reverseString)) {
				System.out.println("'" + setLine + "'" + "is a palindrome.");
				lines++;
			}

		}
	}
		
}
