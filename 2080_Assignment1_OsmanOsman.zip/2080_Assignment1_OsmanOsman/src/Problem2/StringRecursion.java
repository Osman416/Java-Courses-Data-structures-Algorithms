/*
	NAME: OSMAN OSMAN
	ID: 100962928
	CRN:46311
*/
package Problem2;

public class StringRecursion {

	// A:
	public static void printWithSpace(String str) {
		int len = str.length();
		int line = 0;
		String s = str.substring(line, line + 1);

		if (line == len) {
			System.out.println("");
		} else {
			System.out.println(s + " ");
			printWithSpace(s + line++);
		}

	}

	// B:
	public String weave(String string1, String string2) {
		if (string1.isEmpty() || string2.isEmpty()) {
			return string1 + string2;
		}
		return string1.substring(0, 1) + string2.substring(0, 1) + weave(string1.substring(1), string2.substring(1));
	}

	// C:
	public static int lastIndexOf(char ch, String str) {
		if (str.charAt(str.length() - 1) == ch) {
			return str.length() - 1;
		}
		if (str.length() <= 1) {
			return -1;
		}
		return lastIndexOf(ch, str.substring(0, str.length() - 1));
	}

}
