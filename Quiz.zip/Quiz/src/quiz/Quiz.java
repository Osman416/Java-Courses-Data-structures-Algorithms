/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quiz;
import java.util.Scanner;
/**
 *
 * @author Osman
 */
public class Quiz {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    int c = 0;
      Scanner scan = new Scanner (System.in);
      Scanner name = new Scanner (System.in);
      Scanner mark = new Scanner (System.in);
      System.out.print("Quiz");
      System.out.println("\n");
      System.out.println("Please Enter Your First And Last Name:");
      String student;
      student = name.nextLine();
      pauseProg();
     
      
      
      //Q.1
      System.out.println("Whats 2+2 ?");
      System.out.println("a. 4");
      System.out.println("b. 2");
      System.out.println("c. 3");
      System.out.println("d. 100");
      
      String input;
      input = scan.nextLine();
      
      if(input.equalsIgnoreCase("a") ||
              input.equals("4"))
      {          
          System.out.print("\n");
          System.out.println("Correct");
          c++;
          System.out.print("\n");
      }
      else
      {
         System.out.print("\n");
         System.out.println("Wrong");
         System.out.print("\n");
      }
      
      //Q.2
      System.out.println("Whats 2+1");
      System.out.println("a. 4");
      System.out.println("b. 2");
      System.out.println("c. 3");
      System.out.println("d. 100");
      
      input = scan.nextLine();
      
      if(input.equalsIgnoreCase("c") ||
              input.equals("3"))
      {
          System.out.print("\n");
          System.out.println("Correct");
          c++;
          System.out.print("\n");
      }
      else
      {
         System.out.print("\n");
         System.out.println("Wrong");
         System.out.print("\n");
      }
      
      //Q.
      System.out.println("Whats 2+3");
      System.out.println("a. 4");
      System.out.println("b. 2");
      System.out.println("c. 5");
      System.out.println("d. 100");
      
      input = scan.nextLine();
      
      if(input.equalsIgnoreCase("c") ||
              input.equals("5"))
      {
          System.out.print("\n");
          System.out.println("Correct");
          c++;
          System.out.print("\n");
      }
      else
      {
         System.out.print("\n");
         System.out.println("Wrong");
         System.out.print("\n");
      }
      
      //Q.4
      System.out.println("Whats 2+10");
      System.out.println("a. 4");
      System.out.println("b. 2");
      System.out.println("c. 12");
      System.out.println("d. 100");
      
      input = scan.nextLine();
      
      if(input.equalsIgnoreCase("c") ||
              input.equals("12"))
      {
          System.out.print("\n");
          System.out.println("Correct");
          c++;
          System.out.print("\n");
      }
      else
      {
         System.out.print("\n");
         System.out.println("Wrong");
         System.out.print("\n");
      }
     
      clearConsole();
      System.out.println("You got " + c + " out of 4 Correct!");
      System.out.println(c / 4 * 100 + "%");
    }
    public static void pauseProg(){
    System.out.println("Press ENTER to begin Quiz");
    Scanner keyboard = new Scanner(System.in);
    keyboard.nextLine();
}
    
    public final static void clearConsole()
{
    try
    {
        final String os = System.getProperty("os.name");

        if (os.contains("Windows"))
        {
            Runtime.getRuntime().exec("cls");
        }
        else
        {
            Runtime.getRuntime().exec("clear");
        }
    }
    catch (final Exception e)
    {
        //  Handle any exceptions.
    }
}
    
    
}
