/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comp2130_f15lt2b_osmanosman;

/**
 *
 * @author Osman
 */
public class Comp2130_F15LT2B_OsmanOsman {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
