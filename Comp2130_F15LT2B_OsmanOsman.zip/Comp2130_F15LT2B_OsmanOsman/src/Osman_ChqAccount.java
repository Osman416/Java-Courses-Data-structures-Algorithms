/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Date;
/**
 *
 * @author Osman
 */
public class Osman_ChqAccount {
    private int accountID = 0;
    private String holderName;
    private double balance = 0;
    private double annualInterestRate = 0;
    private Date date;

// Constructors
//Creates default account
Osman_ChqAccount() {
    accountID = 0;
    holderName = "";
    balance = 0;
    annualInterestRate = 0;
    date = new Date(); 
}

// Creates account with the specified id and initial balance
Osman_ChqAccount(int newId, double newBalance) {
    accountID = newId;
    balance = newBalance;
    date = new Date();
}

// ACCESSOR METHODS
public int getId() {
    return accountID;
}

public double getBalance() {
    return balance;
}

public double getAnnualInterestRate() {
    return annualInterestRate;
}

public String getDateCreated() {
    return date.toString();
}

public double getMonthlyInterestRate() {
    return annualInterestRate / 12;
}

// MUTATOR METHODS
public void setId(int newAccountID) {
    accountID = newAccountID;
}

public void setBalance(double newBalance) {
    balance = newBalance;
}

public void setAnnualInterestRate(double newAnnualInterestRate) {
    annualInterestRate = newAnnualInterestRate;
}

// METHODS
//Return of monthly interest 
public double getMonthlyInterest() {
    return balance * (getMonthlyInterestRate() / 100);
}

//Decreases "balance" by "amount"
public void withdraw(double amount) {
    balance -= amount;
}

//Increases "balance" by "amount"
public void deposit(double amount) {
    balance += amount;
}
}