package MVC.servlet;

import MVC.servlet.Controller;
import java.io.Serializable;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpSession;

public class Model implements Serializable{
	private static final long serialVersionUID = 1L;

	private int num1;
	private int num2;
	private int result;
	private String operand;

	public Model() {
	    super();
	}

	public Model(int num1, int num2, int result, String operand) {
	    super();
	    this.num1 = num1;
	    this.num2 = num2;
	    this.result = result;
	    this.operand = operand;
	}

	public int getNum1() {
	    return num1;
	}

	public void setNum1(int num1) {
	    this.num1 = num1;
	}

	public int getNum2() {
	    return num2;
	}

	public void setNum2(int num2) {
	    this.num2 = num2;
	}

	public int getResult() {
	    return result;
	}

	public void setResult(int result) {

	    if (operand.equals("+")) {
	    result = num1 + num2;
	    } else if (operand.equals("-")){
	    result = num1 - num2;
	    } else if (operand.equals("*")){
	    result = num1 * num2;
	    } else if (operand.equals("/")){
	    result = num1 / num2;
	    this.result = result;
	}
/*
	public String getOperand() {
	    return operand;
	}

	public void setOperand(String operand) {
	    this.operand = operand;
	}*/}
}
